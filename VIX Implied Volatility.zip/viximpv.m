% VIXIMPV - Approximate implied volatility of VIX options
%   [Sigma,Futures]=VIXIMPV(Mu,Eta,Phi,Y0,K,T,Order)
%
% This function computes approximate values of the Black & Scholes implied volatility of VIX options using the perturbative technique described in [1]. 
% The modelling setup requires that the VIX index dynamics is explicitly computable as a smooth transformation of a purely diffusive, one-dimensional
% Markov process Y. Specifically:
%
%  VIXt=Phi(Yt)
%  dYt=Mu(Yt)dt+Eta(Yt)dWt
%
% The three functions Phi,Mu,Eta must be known explicitly and passed as input to the function.
%
% Input:
%
%      Mu  -  Drift coefficient of Y (function handle)
%     Eta  -  Diffusion coefficient of Y (function handle)
%     Phi  -  Function mapping Y to VIX (function handle or symbolic function)
%      Y0  -  Initial value of Y (scalar)
%       K  -  Strike values (vector)
%       T  -  Maturity (scalar)
%   Order  -  Expansion order (integer between 0 and 4)
%
% Output:
%
%   Sigma  -  Approximate VIX implied volatility
% Futures  -  Approximate VIX futures price
%
%
%Examples:
%
% (1) Heston model
%
%   Kappa=3;
%   Theta=0.04;
%   Epsilon=0.5;
%   Y0=0.035;
%   T=1/48;
%   Mu=@(y) Kappa*(Theta-y);
%   Eta=@(y) Epsilon*sqrt(y);
%   Tau=30/365;
%   a=(1-exp(-Kappa*Tau))/(Kappa*Tau);
%   b=Theta*(1-a);
%   Phi=@(y) sqrt(a*y+b);
%   K=.13:.01:.25;
%   Sigma2=VIXIMPV(Mu,Eta,Phi,Y0,K,T,2);
%   Sigma3=VIXIMPV(Mu,Eta,Phi,Y0,K,T,3);
%   Sigma4=VIXIMPV(Mu,Eta,Phi,Y0,K,T,4);
%   plot(K,[Sigma2; Sigma3; Sigma4],'LineWidth',2);
%   axis tight;
%   grid on;
%
% (2) Mean-reverting CEV model
%
%   Kappa=3;
%   Theta=0.04;
%   Epsilon=1.5;
%   Y0=0.035;
%   T=1/48;
%   Mu=@(y) Kappa*(Theta-y);
%   Eta=@(y) Epsilon*y;
%   Tau=30/365;
%   a=(1-exp(-Kappa*Tau))/(Kappa*Tau);
%   b=Theta*(1-a);
%   Phi=@(y) sqrt(a*y+b);
%   K=.13:.01:.25;
%   Sigma2=VIXIMPV(Mu,Eta,Phi,Y0,K,T,2);
%   Sigma3=VIXIMPV(Mu,Eta,Phi,Y0,K,T,3);
%   Sigma4=VIXIMPV(Mu,Eta,Phi,Y0,K,T,4);
%   plot(K,[Sigma2; Sigma3; Sigma4],'LineWidth',2);
%   axis tight;
%   grid on;
%
% (3) Exp-OU model
%
%   Lambda=10;
%   Theta=0.02;
%   Epsilon=3.5;
%   Y0=-3.3;
%   T=1/48;
%   Mu=@(y) Lambda*(log(Theta)-y);
%   Eta=@(y) Epsilon;
%   syms x y;
%   Tau=30/365;
%   g=exp(exp(-Lambda*x).*y+log(Theta)*(1-exp(-Lambda*x))+Epsilon^2/(4*Lambda)*(1-exp(-2*Lambda*x)));
%   Phi=(1/sqrt(Tau))*sqrt(int(g,x,0,Tau));
%   VIX0=double(subs(Phi,y,Y0));
%   K=.13:.01:.25;
%   Sigma2=VIXIMPV(Mu,Eta,Phi,Y0,K,T,2);
%   Sigma3=VIXIMPV(Mu,Eta,Phi,Y0,K,T,3);
%   Sigma4=VIXIMPV(Mu,Eta,Phi,Y0,K,T,4);
%   plot(K,[Sigma2; Sigma3; Sigma4],'LineWidth',2);
%   axis tight;
%   grid on;
%
% References:
%
% [BNP2017] Barletta, A., Nicolato, E., & Pagliarani, S. (2017). 
%          The Short-Time Behaviour of VIX Implied Volatilities in a Multifactor Stochastic Volatility Framework.
%          Available at: <a href="matlab:web('https://ssrn.com/abstract=2942262')">SSRN</a>.

% Author: Andrea Barletta, Aarhus University, abarletta@econ.au.dk
% Version: November 2017

function [Sigma,Futures]=viximpv(Mu,Eta,Phi,Y0,K,T,Order)

%% Checking parameters

if (~isa(Mu,'function_handle')) || ...
   (~isa(Eta,'function_handle')) || ...
   (~(isa(Phi,'function_handle')||isa(Phi,'sym')))
error('Mu,Eta and Phi must be function handles. See ''help function_handle''.');
end

if length(T)>1
    error('Maturity must be a scalar');
end

%% Computing VIX futures

Futures=fwd(Mu,Eta,Phi,Y0,T);
        
%% Computing VIX implied volatilities
switch Order
    case 0
        Sigma=iv0(Mu,Eta,Phi,Y0,Futures,K,T);
    case 1
        Sigma=iv1(Mu,Eta,Phi,Y0,Futures,K,T);
    case 2
        Sigma=iv2(Mu,Eta,Phi,Y0,Futures,K,T);
    case 3
        Sigma=iv3(Mu,Eta,Phi,Y0,Futures,K,T);
    case 4
        Sigma=iv4(Mu,Eta,Phi,Y0,Futures,K,T);
end

end
