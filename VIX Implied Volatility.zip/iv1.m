%% IV1 - Auxiliary function
%
% See also: viximpv.m
%

% Author: Andrea Barletta, Aarhus University, abarletta@econ.au.dk
% Version: November 2017
function sigmabar=iv1(Mu,Eta,Phi,Y0,F,K,T)

%% Pre-computing values of model coefficients and their derivatives
syms y;
k=log(K);
f=log(F);
% Phi
if isa(Phi,'function_handle')
    Phi=Phi(y);
else
    Phi=subs(Phi,y);
end
phi=double(subs(Phi,y,Y0));
phi1=double(subs(diff(Phi,y,1), y, Y0));
phi2=double(subs(diff(Phi,y,2), y, Y0));
% Eta
eta=Eta(Y0);
eta1=double(subs(diff(Eta(y),y,1), y, Y0));
% Mu
mu=Mu(Y0);

%% Computing ivol
sigmabar=(1/4).*phi.^(-3).*phi1.^(-1).*((-2).*(f+(-1).*k).*phi.^3.*(eta1.* ...
  phi1+eta.*phi2)+(-1).*eta.^3.*phi1.^4.*T+eta.*phi.*phi1.^2.*((-2) ...
  .*mu.*phi1+eta.*(eta1.*phi1+eta.*phi2)).*T+2.*phi.^2.*phi1.*(eta.* ...
  mu.*phi2.*T+phi1.*(eta.*(2+f+(-1).*k)+eta1.*mu.*T)));
