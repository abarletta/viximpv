%% FWD - Auxiliary function
%
% See also: viximpv.m
%

% Author: Andrea Barletta, Aarhus University, abarletta@econ.au.dk
% Version: November 2017
function Fbar=fwd(Mu,Eta,Phi,Y0,T)

%% Pre-computing values of model coefficients and their derivatives
syms y;
% Phi
if isa(Phi,'function_handle')
    Phi=Phi(y);
else
    Phi=subs(Phi,y);
end
phi=double(subs(Phi,y,Y0));
phi1=double(subs(diff(Phi,y,1), y, Y0));
phi2=double(subs(diff(Phi,y,2), y, Y0));
phi3=double(subs(diff(Phi,y,3), y, Y0));
phi4=double(subs(diff(Phi,y,4), y, Y0));
phi5=double(subs(diff(Phi,y,5), y, Y0));
phi6=double(subs(diff(Phi,y,6), y, Y0));
% Eta
eta=Eta(Y0);
eta1=double(subs(diff(Eta(y),y,1), y, Y0));
eta2=double(subs(diff(Eta(y),y,2), y, Y0));
eta3=double(subs(diff(Eta(y),y,3), y, Y0));
eta4=double(subs(diff(Eta(y),y,4), y, Y0));

% Mu
mu=Mu(Y0);
mu1=double(subs(diff(Mu(y),y,1), y, Y0));
mu2=double(subs(diff(Mu(y),y,2), y, Y0));
mu3=double(subs(diff(Mu(y),y,3), y, Y0));
mu4=double(subs(diff(Mu(y),y,4), y, Y0));

%% Computation of futures
Fbar=phi+(1/48).*T.*(8.*mu.^3.*phi3.*T.^2+4.*mu.^2.*T.*(2.*mu2.*phi1.* ...
  T+3.*eta.*(2.*eta1.*phi3+eta.*phi4).*T+2.*phi2.*(3+(eta1.^2+eta.* ...
  eta2+3.*mu1).*T))+eta.^2.*(2.*phi1.*T.*(eta.*(4.*eta1.*mu3+eta.* ...
  mu4).*T+2.*mu2.*(3+(eta1.^2+eta.*eta2+3.*mu1).*T))+2.*phi2.*(12+ ...
  T.*(6.*eta.*eta2+2.*eta1.^4.*T+8.*mu1.^2.*T+2.*eta.*eta1.*(4.* ...
  eta.*eta3+7.*mu2).*T+eta.^2.*(5.*eta2.^2+eta.*eta4+4.*mu3).*T+4.* ...
  mu1.*(3+2.*eta.*eta2.*T)+2.*eta1.^2.*(3+8.*eta.*eta2.*T+4.*mu1.*T) ...
  ))+eta.*T.*(32.*eta1.^3.*phi3.*T+38.*eta.*eta1.^2.*phi4.*T+ ...
  eta.^3.*phi6.*T+4.*eta1.*(3.*eta.^2.*phi5.*T+2.*phi3.*(3+7.*eta.* ...
  eta2.*T+5.*mu1.*T))+2.*eta.*((4.*eta.*eta3+7.*mu2).*phi3.*T+phi4.* ...
  (3+7.*eta.*eta2.*T+6.*mu1.*T))))+mu.*(6.*eta.^4.*phi5.*T.^2+8.* ...
  phi1.*(6+T.*(3.*mu1+mu1.^2.*T+eta.*(eta1.*mu2+eta.*mu3).*T))+4.* ...
  eta.*T.*(2.*eta1.^3.*phi2.*T+11.*eta.*eta1.^2.*phi3.*T+eta1.*(9.* ...
  eta.^2.*phi4.*T+phi2.*(6+8.*eta.*eta2.*T+6.*mu1.*T))+eta.*((2.* ...
  eta.*eta3+7.*mu2).*phi2.*T+phi3.*(6+7.*eta.*eta2.*T+9.*mu1.*T)))));

