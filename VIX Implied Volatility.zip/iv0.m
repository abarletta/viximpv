%% IVO - Auxiliary function
%
% See also: viximpv.m
%

% Author: Andrea Barletta, Aarhus University, abarletta@econ.au.dk
% Version: November 2017

function sigmabar=iv0(Mu,Eta,Phi,Y0,F,K,T)

%% Pre-computing values of model coefficients and their derivatives
syms y;
% Phi
if isa(Phi,'function_handle')
    Phi=Phi(y);
else
    Phi=subs(Phi,y);
end
phi=double(subs(Phi,y,Y0));
phi1=double(subs(diff(Phi,y,1), y, Y0));
% Eta
eta=Eta(Y0);

%% Computing ivol
sigmabar=(eta.*phi.^(-1).*phi1)*ones(size(K));
